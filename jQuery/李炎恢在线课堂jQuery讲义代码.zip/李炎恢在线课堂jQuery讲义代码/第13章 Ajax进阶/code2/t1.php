﻿<?php
	echo 'test1.php'
?>