﻿<?php
	echo 'test2.php'
?>