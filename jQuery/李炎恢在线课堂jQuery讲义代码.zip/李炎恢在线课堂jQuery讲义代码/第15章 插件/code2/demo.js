﻿

$(function () {

	$('.list').eq(0).nav('orange');
	
});


























