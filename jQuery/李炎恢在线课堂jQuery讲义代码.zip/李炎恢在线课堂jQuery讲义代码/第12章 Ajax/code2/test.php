﻿<?php
	if ($_POST['url'] == 'ycku') {
		echo '瓢城Web俱乐部';
	} else {
		echo '木有！';
	}


	/*


	if ($_GET['url'] == 'ycku') {
		echo '瓢城Web俱乐部';
	} else {
		echo '木有！';
	}

	
	*/
	
?>