﻿<?php
	echo $_POST['user'].' - '.$_POST['email'];
?>